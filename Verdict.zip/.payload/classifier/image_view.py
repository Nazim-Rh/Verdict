"""Interactive, DS9-style cutout display.

Unlike a static PNG, FitsImageView keeps the raw cropped pixel array and
its per-cutout WCS in memory and renders them live: changing the color
map, scale function, or contrast redraws instantly (no re-crop, no disk
round-trip). It also tracks the mouse and reports the pixel value and
WCS position under the cursor, the same information DS9 shows in its
bottom info bar.
"""
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets

from . import theme


class FitsImageView(QtWidgets.QWidget):
    # Emits a dict: {"x": int, "y": int, "value": float, "ra": float, "dec": float}
    # (ra/dec omitted if no WCS is available). x/y are 1-indexed image
    # coordinates, DS9-style (bottom-left pixel is (1, 1)).
    pixelHover = QtCore.pyqtSignal(dict)
    hoverCleared = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setMinimumSize(300, 300)

        self._data = None            # 2D numpy array (native orientation, row0=bottom)
        self._cutout_wcs = None      # astropy WCS matching _data, or None
        self._aperture_radius = 3.0
        self._center_xy = None       # (cx, cy) in data pixel coords

        self._pct_low = 2.0
        self._pct_high = 98.0
        self._cmap_name = "Grayscale"
        self._scale_func = "linear"

        self.fit_to_panel = True
        self.zoom_pct = 100

        self._display_image = None   # QImage, row0 = top of display
        self._draw_rect = QtCore.QRect()
        self._img_scale = 1.0

    # ------------------------------------------------------------------
    # Data / settings
    # ------------------------------------------------------------------
    def set_cutout(self, data, cutout_wcs, aperture_radius=None):
        self._data = data
        self._cutout_wcs = cutout_wcs
        if aperture_radius is not None:
            self._aperture_radius = aperture_radius
        h, w = data.shape
        self._center_xy = ((w - 1) / 2.0, (h - 1) / 2.0)
        self._rebuild_image()

    def set_aperture_radius(self, radius):
        self._aperture_radius = radius
        self.update()

    def set_display_settings(self, pct_low, pct_high, cmap_name, scale_func):
        self._pct_low = pct_low
        self._pct_high = pct_high
        self._cmap_name = cmap_name
        self._scale_func = (scale_func or "linear").lower()
        self._rebuild_image()

    def clear(self):
        self._data = None
        self._cutout_wcs = None
        self._center_xy = None
        self._display_image = None
        self.update()

    # ------------------------------------------------------------------
    # Zoom (mirrors DS9's Zoom controls)
    # ------------------------------------------------------------------
    def zoom_in(self):
        self.fit_to_panel = False
        self.zoom_pct = min(1600, round(self.zoom_pct * 1.25))
        self.update()

    def zoom_out(self):
        self.fit_to_panel = False
        self.zoom_pct = max(10, round(self.zoom_pct / 1.25))
        self.update()

    def zoom_fit(self):
        self.fit_to_panel = True
        self.update()

    def set_zoom(self, pct):
        self.fit_to_panel = False
        self.zoom_pct = int(pct)
        self.update()

    def current_zoom_label(self):
        return "Fit" if self.fit_to_panel else f"{self.zoom_pct}%"

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------
    def _rebuild_image(self):
        if self._data is None:
            self._display_image = None
            self.update()
            return

        # Flip vertically so row0 of the *display* is the top of the sky
        # (matches the old origin="lower" matplotlib convention).
        data = np.flipud(self._data)
        finite_mask = np.isfinite(data)
        finite = data[finite_mask]

        if finite.size == 0:
            vmin, vmax = 0.0, 1.0
        else:
            vmin, vmax = np.nanpercentile(finite, [self._pct_low, self._pct_high])
            if vmin == vmax:
                vmax = vmin + 1.0

        norm = np.clip((data - vmin) / (vmax - vmin), 0.0, 1.0)
        norm = np.where(finite_mask, norm, 0.0)

        if self._scale_func == "log":
            a = 1000.0
            norm = np.log1p(a * norm) / np.log1p(a)
        elif self._scale_func == "sqrt":
            norm = np.sqrt(norm)
        elif self._scale_func == "squared":
            norm = norm ** 2

        idx = np.clip((norm * 255.0).astype(np.uint8), 0, 255)
        lut = theme.colormap_lut(self._cmap_name)
        rgb = lut[idx]
        rgb[~finite_mask] = (0, 0, 0)
        rgb = np.ascontiguousarray(rgb)

        h, w, _ = rgb.shape
        qimg = QtGui.QImage(rgb.data, w, h, 3 * w, QtGui.QImage.Format_RGB888)
        self._display_image = qimg.copy()  # detach from the numpy buffer
        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.fillRect(self.rect(), QtGui.QColor(theme.PANEL_BLACK))

        if self._display_image is None:
            painter.setPen(QtGui.QColor(theme.MUTED_TEXT))
            painter.drawText(self.rect(), QtCore.Qt.AlignCenter,
                              "Select a row to view its cutout")
            painter.end()
            return

        img_w, img_h = self._display_image.width(), self._display_image.height()
        if self.fit_to_panel:
            scale = min(self.width() / img_w, self.height() / img_h) if img_w and img_h else 1.0
        else:
            scale = self.zoom_pct / 100.0
        scale = max(scale, 0.01)

        draw_w = max(1, round(img_w * scale))
        draw_h = max(1, round(img_h * scale))
        x = (self.width() - draw_w) // 2
        y = (self.height() - draw_h) // 2
        self._draw_rect = QtCore.QRect(x, y, draw_w, draw_h)
        self._img_scale = scale

        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform, scale < 4)
        painter.drawImage(self._draw_rect, self._display_image)

        if self._center_xy is not None:
            cx, cy = self._center_xy
            px = x + (cx + 0.5) * scale
            py = y + (img_h - 1 - cy + 0.5) * scale
            r = max(self._aperture_radius * scale, 2.0)
            painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
            painter.setPen(QtGui.QPen(QtGui.QColor("#ff5555"), 1.5))
            painter.setBrush(QtCore.Qt.NoBrush)
            painter.drawEllipse(QtCore.QPointF(px, py), r, r)

        painter.end()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self.fit_to_panel:
            self.update()

    # ------------------------------------------------------------------
    # Hover: pixel value + WCS readout, DS9-style
    # ------------------------------------------------------------------
    def mouseMoveEvent(self, event):
        if self._data is None or self._display_image is None or self._draw_rect.isNull():
            return
        pos = event.pos()
        if not self._draw_rect.contains(pos):
            self.hoverCleared.emit()
            return

        img_h = self._display_image.height()
        rel_x = (pos.x() - self._draw_rect.x()) / self._img_scale
        rel_y = (pos.y() - self._draw_rect.y()) / self._img_scale
        data_col = int(np.floor(rel_x))
        row_from_top = int(np.floor(rel_y))
        data_row = img_h - 1 - row_from_top

        h, w = self._data.shape
        if not (0 <= data_row < h and 0 <= data_col < w):
            self.hoverCleared.emit()
            return

        value = float(self._data[data_row, data_col])
        info = {"x": data_col + 1, "y": data_row + 1, "value": value}  # 1-indexed, DS9-style

        if self._cutout_wcs is not None:
            try:
                ra, dec = self._cutout_wcs.all_pix2world(data_col, data_row, 0)
                info["ra"] = float(ra)
                info["dec"] = float(dec)
            except Exception:
                pass

        self.pixelHover.emit(info)

    def leaveEvent(self, event):
        self.hoverCleared.emit()
        super().leaveEvent(event)
