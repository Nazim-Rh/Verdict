"""Crossmatch mode: match two catalogues (CSV or FITS tables) against each
other by sky position (RA/Dec, spherical angular separation) or pixel
position (X/Y, Euclidean distance), and save the matched output table.

This is fully independent of Judge mode: no FITS image is needed here,
only the two tables being matched.
"""
import os

import numpy as np
import pandas as pd
import astropy.units as u
from astropy.coordinates import SkyCoord
from scipy.spatial import cKDTree

from PyQt5 import QtCore, QtWidgets

from .columns import guess_columns, guess_xy

MATCH_MODES = ["One-to-one (best match)", "One-to-many", "Many-to-one"]


def read_table(path):
    """Read a CSV or FITS table into a pandas DataFrame."""
    if path.lower().endswith((".fits", ".fit")):
        from astropy.table import Table
        tbl = Table.read(path)
        # Columns with >1 value per row (e.g. per-source arrays) can't
        # become a DataFrame column; drop them rather than failing outright.
        keep = [name for name in tbl.colnames if len(tbl[name].shape) <= 1]
        return tbl[keep].to_pandas()
    return pd.read_csv(path)


def _numeric_positions(df, col1, col2):
    """Return (orig_positions, values) for the given two columns, keeping
    only rows where both are finite numbers. orig_positions are positions
    into `df` (0-based, matching .iloc), so they stay valid for indexing
    the original (unfiltered) DataFrame later."""
    v1 = pd.to_numeric(df[col1], errors="coerce").to_numpy(dtype=float)
    v2 = pd.to_numeric(df[col2], errors="coerce").to_numpy(dtype=float)
    mask = np.isfinite(v1) & np.isfinite(v2)
    orig_positions = np.flatnonzero(mask)
    return orig_positions, np.column_stack([v1[mask], v2[mask]])


def _assign_pairs(candidates, mode):
    """candidates: list of (separation, i, j), i indexing table A, j
    indexing table B. Greedily assigns closest pairs first, respecting the
    uniqueness constraint implied by `mode`:
      - one-to-one: each A row and each B row used at most once
      - one-to-many: each A row used at most once; B rows may repeat
      - many-to-one: each B row used at most once; A rows may repeat
    """
    restrict_i = mode != MATCH_MODES[2]   # not many-to-one -> A unique
    restrict_j = mode != MATCH_MODES[1]   # not one-to-many -> B unique
    used_i, used_j, kept = set(), set(), []
    for sep, i, j in sorted(candidates, key=lambda t: t[0]):
        if restrict_i and i in used_i:
            continue
        if restrict_j and j in used_j:
            continue
        kept.append((i, j, sep))
        used_i.add(i)
        used_j.add(j)
    return kept


def _build_result(df1, df2, kept, sep_col, sep_unit_label):
    rows1 = [i for i, j, s in kept]
    rows2 = [j for i, j, s in kept]
    seps = [s for i, j, s in kept]
    out1 = df1.iloc[rows1].reset_index(drop=True).add_suffix("_1")
    out2 = df2.iloc[rows2].reset_index(drop=True).add_suffix("_2")
    result = pd.concat([out1, out2], axis=1)
    result[sep_col] = seps
    result.attrs["separation_unit"] = sep_unit_label
    return result


def crossmatch_sky(df1, ra1, dec1, df2, ra2, dec2, radius_arcsec, mode):
    """Match by spherical angular separation between (ra1, dec1) in df1
    and (ra2, dec2) in df2, within radius_arcsec, using `mode`
    (one of MATCH_MODES). Rows with missing/non-numeric RA or Dec are
    skipped rather than causing a crash.

    Returns (matched_df, matched_positions_1, matched_positions_2): the
    combined matched table, plus the sets of 0-based row positions (into
    the original df1 / df2, matching .iloc) that took part in a match --
    used by the caller to build the "A only" / "B only" tables."""
    orig1, vals1 = _numeric_positions(df1, ra1, dec1)
    orig2, vals2 = _numeric_positions(df2, ra2, dec2)
    if len(orig1) == 0 or len(orig2) == 0:
        return _build_result(df1, df2, [], "separation_arcsec", "arcsec"), set(), set()

    c1 = SkyCoord(ra=vals1[:, 0] * u.deg, dec=vals1[:, 1] * u.deg)
    c2 = SkyCoord(ra=vals2[:, 0] * u.deg, dec=vals2[:, 1] * u.deg)
    # SkyCoord.search_around_sky(self, searcharoundcoords, seplimit) delegates to
    # the module-level search_around_sky with self and searcharoundcoords SWAPPED
    # (astropy internal implementation detail). So calling c1.search_around_sky(c2)
    # returns (idx_into_c2, idx_into_c1, ...), not (idx_into_c1, idx_into_c2, ...).
    idx_c2, idx_c1, sep2d, _ = c1.search_around_sky(c2, radius_arcsec * u.arcsec)
    # idx_c1/idx_c2 index into the filtered (numeric-only) subsets -- map them
    # back to positions in the original DataFrames before using .iloc.
    mapped1 = orig1[idx_c1]
    mapped2 = orig2[idx_c2]
    candidates = list(zip(sep2d.arcsec.tolist(), mapped1.tolist(), mapped2.tolist()))
    kept = _assign_pairs(candidates, mode)
    result = _build_result(df1, df2, kept, "separation_arcsec", "arcsec")
    matched1 = {i for i, j, s in kept}
    matched2 = {j for i, j, s in kept}
    return result, matched1, matched2


def crossmatch_pixel(df1, x1, y1, df2, x2, y2, radius_px, mode):
    """Match by Euclidean pixel distance between (x1, y1) in df1 and
    (x2, y2) in df2, within radius_px, using `mode` (one of MATCH_MODES).
    Rows with missing/non-numeric X or Y are skipped rather than causing
    a crash.

    Returns (matched_df, matched_positions_1, matched_positions_2), same
    shape as crossmatch_sky."""
    orig1, pts1 = _numeric_positions(df1, x1, y1)
    orig2, pts2 = _numeric_positions(df2, x2, y2)
    if len(orig1) == 0 or len(orig2) == 0:
        return _build_result(df1, df2, [], "separation_px", "pixel"), set(), set()

    tree2 = cKDTree(pts2)
    neighbor_lists = tree2.query_ball_point(pts1, r=radius_px)
    candidates = []
    for i, js in enumerate(neighbor_lists):
        for j in js:
            d = float(np.hypot(pts1[i, 0] - pts2[j, 0], pts1[i, 1] - pts2[j, 1]))
            candidates.append((d, int(orig1[i]), int(orig2[j])))
    kept = _assign_pairs(candidates, mode)
    result = _build_result(df1, df2, kept, "separation_px", "pixel")
    matched1 = {i for i, j, s in kept}
    matched2 = {j for i, j, s in kept}
    return result, matched1, matched2


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------
class _TablePane(QtWidgets.QGroupBox):
    """One side of the crossmatch UI: load a table and remember which
    columns to match on."""
    loaded = QtCore.pyqtSignal()

    def __init__(self, title, parent=None):
        super().__init__(title, parent)
        self.df = None
        self.path = None
        self.ra_col = self.dec_col = self.x_col = self.y_col = None
        layout = QtWidgets.QVBoxLayout(self)
        self.open_btn = QtWidgets.QPushButton("Open table (FITS/CSV)...")
        self.open_btn.clicked.connect(self._open)
        self.status_label = QtWidgets.QLabel("No table loaded")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.open_btn)
        layout.addWidget(self.status_label)

    def _open(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Open table", os.path.expanduser("~"),
            "Table files (*.csv *.fits *.fit);;All files (*)")
        if not path:
            return
        try:
            df = read_table(path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Error reading table", str(e))
            return
        if df.empty:
            QtWidgets.QMessageBox.warning(self, "Empty table", "That table has no rows.")
            return
        self.df = df.reset_index(drop=True)
        self.path = path
        self.status_label.setText(f"{os.path.basename(path)}  ({len(self.df)} rows)")
        self.loaded.emit()

    def pick_columns(self, use_sky):
        """Ask which columns to match on, given the radius unit. Returns
        True on success, False if the user cancelled."""
        if self.df is None:
            return False
        columns = list(self.df.columns)
        if use_sky:
            guess1, guess2, _ = guess_columns(columns)
            labels = ("RA column:", "Dec column:")
        else:
            guess1, guess2 = guess_xy(columns)
            labels = ("X column:", "Y column:")

        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle(f"{self.title()}: pick match columns")
        form = QtWidgets.QFormLayout(dialog)
        combo1, combo2 = QtWidgets.QComboBox(), QtWidgets.QComboBox()
        combo1.addItems(columns)
        combo2.addItems(columns)
        if guess1 in columns:
            combo1.setCurrentText(guess1)
        if guess2 in columns:
            combo2.setCurrentText(guess2)
        form.addRow(labels[0], combo1)
        form.addRow(labels[1], combo2)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return False

        if use_sky:
            self.ra_col, self.dec_col = combo1.currentText(), combo2.currentText()
        else:
            self.x_col, self.y_col = combo1.currentText(), combo2.currentText()
        return True


class CrossmatchWidget(QtWidgets.QWidget):
    """Independent of Judge mode: import two tables, set a matching
    radius (pixel or arcsec) and matching type, run the match, and save
    the result as CSV or FITS."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.result_df = None       # sources matched in both A and B
        self.a_only_df = None       # sources present in A only
        self.b_only_df = None       # sources present in B only

        layout = QtWidgets.QVBoxLayout(self)

        tables_row = QtWidgets.QHBoxLayout()
        self.pane_a = _TablePane("Table A")
        self.pane_b = _TablePane("Table B")
        tables_row.addWidget(self.pane_a)
        tables_row.addWidget(self.pane_b)
        layout.addLayout(tables_row)

        opts_row = QtWidgets.QHBoxLayout()
        opts_row.addWidget(QtWidgets.QLabel("Radius:"))
        self.radius_spin = QtWidgets.QDoubleSpinBox()
        self.radius_spin.setDecimals(3)
        self.radius_spin.setRange(0.001, 1_000_000)
        self.radius_spin.setValue(1.5)
        opts_row.addWidget(self.radius_spin)

        self.unit_combo = QtWidgets.QComboBox()
        self.unit_combo.addItems(["arcsec", "pixel"])
        self.unit_combo.setToolTip(
            "arcsec: spherical angular separation between RA/Dec positions.\n"
            "pixel: Euclidean distance between X/Y positions.")
        opts_row.addWidget(self.unit_combo)

        opts_row.addSpacing(20)
        opts_row.addWidget(QtWidgets.QLabel("Match type:"))
        self.mode_combo = QtWidgets.QComboBox()
        self.mode_combo.addItems(MATCH_MODES)
        opts_row.addWidget(self.mode_combo)
        opts_row.addStretch(1)
        layout.addLayout(opts_row)

        run_row = QtWidgets.QHBoxLayout()
        self.run_btn = QtWidgets.QPushButton("Run crossmatch")
        self.run_btn.clicked.connect(self._run)
        run_row.addWidget(self.run_btn)
        self.result_label = QtWidgets.QLabel("")
        run_row.addWidget(self.result_label)
        run_row.addStretch(1)
        layout.addLayout(run_row)

        # Three tables: sources matched in both, sources in A only, and
        # sources in B only. A tab switch is how the user picks which one
        # the Save button below acts on.
        self.result_tabs = QtWidgets.QTabWidget()
        self.result_tabs.setElideMode(QtCore.Qt.ElideNone)

        self.match_table = QtWidgets.QTableWidget()
        self.match_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.result_tabs.addTab(self.match_table, "Matched (A && B)")

        self.a_only_table = QtWidgets.QTableWidget()
        self.a_only_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.result_tabs.addTab(self.a_only_table, "A only")

        self.b_only_table = QtWidgets.QTableWidget()
        self.b_only_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.result_tabs.addTab(self.b_only_table, "B only")

        layout.addWidget(self.result_tabs, 1)

        save_row = QtWidgets.QHBoxLayout()
        self.save_btn = QtWidgets.QPushButton("Save table shown in current tab...")
        self.save_btn.setToolTip(
            "Saves whichever of the three tables (Matched / A only / B only) "
            "is currently selected above.")
        self.save_btn.setEnabled(False)
        self.save_btn.clicked.connect(self._save)
        save_row.addWidget(self.save_btn)
        save_row.addStretch(1)
        layout.addLayout(save_row)

    def _run(self):
        if self.pane_a.df is None or self.pane_b.df is None:
            QtWidgets.QMessageBox.information(
                self, "Load both tables", "Open Table A and Table B first.")
            return

        use_sky = self.unit_combo.currentText() == "arcsec"
        if not self.pane_a.pick_columns(use_sky):
            return
        if not self.pane_b.pick_columns(use_sky):
            return

        radius = self.radius_spin.value()
        mode = self.mode_combo.currentText()
        try:
            if use_sky:
                result, matched_a, matched_b = crossmatch_sky(
                    self.pane_a.df, self.pane_a.ra_col, self.pane_a.dec_col,
                    self.pane_b.df, self.pane_b.ra_col, self.pane_b.dec_col,
                    radius, mode)
            else:
                result, matched_a, matched_b = crossmatch_pixel(
                    self.pane_a.df, self.pane_a.x_col, self.pane_a.y_col,
                    self.pane_b.df, self.pane_b.x_col, self.pane_b.y_col,
                    radius, mode)
        except Exception as e:
            import traceback
            traceback.print_exc()
            QtWidgets.QMessageBox.critical(
                self, "Crossmatch failed", f"{type(e).__name__}: {e}")
            return

        # Sources present in A but not matched to anything in B, and vice
        # versa -- same original columns, no _1/_2 suffixing needed since
        # each is a single table.
        a_only = self.pane_a.df.drop(index=sorted(matched_a)).reset_index(drop=True)
        b_only = self.pane_b.df.drop(index=sorted(matched_b)).reset_index(drop=True)

        self.result_df = result
        self.a_only_df = a_only
        self.b_only_df = b_only

        self.result_label.setText(
            f"{len(result)} matched  |  {len(a_only)} in A only  |  {len(b_only)} in B only")
        self._populate_table(self.match_table, result)
        self._populate_table(self.a_only_table, a_only)
        self._populate_table(self.b_only_table, b_only)
        self.save_btn.setEnabled(len(result) > 0 or len(a_only) > 0 or len(b_only) > 0)

    def _populate_table(self, table_widget, df):
        table_widget.clear()
        table_widget.setColumnCount(len(df.columns))
        table_widget.setHorizontalHeaderLabels(list(df.columns))
        table_widget.setRowCount(len(df))
        for row in range(len(df)):
            for col, name in enumerate(df.columns):
                table_widget.setItem(
                    row, col, QtWidgets.QTableWidgetItem(str(df.iat[row, col])))
        table_widget.resizeColumnsToContents()

    # ------------------------------------------------------------------
    # Save: acts on whichever of the three tabs is currently selected,
    # and suggests a filename derived from Table A / Table B's own
    # filenames (editable by the user before the dialog actually saves).
    # ------------------------------------------------------------------
    @staticmethod
    def _stem(path):
        return os.path.splitext(os.path.basename(path))[0] if path else "table"

    def _current_tab_data(self):
        """Returns (df, default_stem, dialog_title) for whichever tab is
        selected, or (None, None, None) if there's nothing to save yet."""
        index = self.result_tabs.currentIndex()
        stem_a = self._stem(self.pane_a.path)
        stem_b = self._stem(self.pane_b.path)
        if index == 0:
            return self.result_df, f"{stem_a}_{stem_b}_crossmatch", "Save crossmatched table"
        if index == 1:
            return self.a_only_df, f"{stem_a}_only", "Save Table A only"
        if index == 2:
            return self.b_only_df, f"{stem_b}_only", "Save Table B only"
        return None, None, None

    def _save(self):
        df, default_name, title = self._current_tab_data()
        if df is None or df.empty:
            QtWidgets.QMessageBox.information(
                self, "Nothing to save", "The currently selected tab has no rows.")
            return

        default_path = os.path.join(os.path.expanduser("~"), default_name)
        path, chosen_filter = QtWidgets.QFileDialog.getSaveFileName(
            self, title, default_path,
            "CSV files (*.csv);;FITS files (*.fits)")
        if not path:
            return
        want_fits = path.lower().endswith((".fits", ".fit")) or "FITS" in chosen_filter
        try:
            if want_fits:
                if not path.lower().endswith((".fits", ".fit")):
                    path += ".fits"
                from astropy.table import Table
                Table.from_pandas(df).write(path, overwrite=True)
            else:
                if not path.lower().endswith(".csv"):
                    path += ".csv"
                df.to_csv(path, index=False)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Error saving table", str(e))
            return
        QtWidgets.QMessageBox.information(self, "Saved", f"Table saved to:\n{path}")
