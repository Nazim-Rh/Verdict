"""Dark, DS9-inspired theme for the Verdict classifier GUI.

Palette: matte black surfaces, astro blue accents/text, cosmic blue for
the "active/toggled" state of controls. Also provides the colormap LUTs
used by the live cutout renderer (classifier.image_view.FitsImageView).
"""
import functools

import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets

# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------
MATTE_BLACK = "#0a0a0d"     # window background
PANEL_BLACK = "#141417"     # recessed panels (image view, table, hover bar)
SURFACE_BLACK = "#1b1b1f"   # raised controls (buttons, combos) at rest
SURFACE_HOVER = "#232329"   # raised controls on hover
BORDER = "#2a2a2f"
ASTRO_BLUE = "#4fc3f7"      # accent: text, borders, icons
COSMIC_BLUE = "#2f6fed"     # accent: active/checked/pressed state
MUTED_TEXT = "#8a8a92"
TEXT = "#e7e7ea"


STYLESHEET = f"""
QMainWindow, QWidget {{
    background-color: {MATTE_BLACK};
    color: {TEXT};
    font-size: 12px;
}}
QMenuBar {{
    background-color: {MATTE_BLACK};
    color: {TEXT};
}}
QMenuBar::item:selected {{
    background-color: {SURFACE_BLACK};
    color: {ASTRO_BLUE};
}}
QMenu {{
    background-color: {SURFACE_BLACK};
    color: {TEXT};
    border: 1px solid {BORDER};
}}
QMenu::item:selected {{
    background-color: {COSMIC_BLUE};
    color: white;
}}

QPushButton {{
    background-color: {SURFACE_BLACK};
    color: {ASTRO_BLUE};
    border: 1px solid {BORDER};
    border-radius: 6px;
    padding: 6px 12px;
}}
QPushButton:hover {{
    background-color: {SURFACE_HOVER};
    border: 1px solid {ASTRO_BLUE};
}}
QPushButton:pressed {{
    background-color: {COSMIC_BLUE};
    color: white;
    border: 1px solid {COSMIC_BLUE};
}}
QPushButton:checked {{
    background-color: {COSMIC_BLUE};
    color: white;
    border: 1px solid {COSMIC_BLUE};
    font-weight: 600;
}}
QPushButton:disabled {{
    color: {MUTED_TEXT};
    border-color: {BORDER};
}}

QTableWidget {{
    background-color: {PANEL_BLACK};
    alternate-background-color: #17171a;
    gridline-color: {BORDER};
    selection-background-color: {COSMIC_BLUE};
    selection-color: white;
    border: 1px solid {BORDER};
}}
QHeaderView::section {{
    background-color: {SURFACE_BLACK};
    color: {ASTRO_BLUE};
    border: 1px solid {BORDER};
    padding: 4px;
}}
QScrollBar:vertical, QScrollBar:horizontal {{
    background: {PANEL_BLACK};
}}
QScrollBar::handle {{
    background: {BORDER};
    border-radius: 4px;
}}
QScrollBar::handle:hover {{
    background: {ASTRO_BLUE};
}}
QComboBox, QSpinBox, QDoubleSpinBox {{
    background-color: {SURFACE_BLACK};
    color: {TEXT};
    border: 1px solid {BORDER};
    border-radius: 4px;
    padding: 3px 6px;
}}
QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover {{
    border: 1px solid {ASTRO_BLUE};
}}
QComboBox QAbstractItemView {{
    background-color: {SURFACE_BLACK};
    color: {TEXT};
    selection-background-color: {COSMIC_BLUE};
    selection-color: white;
}}
QCheckBox {{
    color: {TEXT};
    spacing: 6px;
}}
QCheckBox::indicator {{
    width: 14px;
    height: 14px;
    border: 1px solid {BORDER};
    border-radius: 3px;
    background: {SURFACE_BLACK};
}}
QCheckBox::indicator:hover {{
    border: 1px solid {ASTRO_BLUE};
}}
QCheckBox::indicator:checked {{
    background: {COSMIC_BLUE};
    border: 1px solid {COSMIC_BLUE};
}}
QStatusBar {{
    background-color: {MATTE_BLACK};
    color: {MUTED_TEXT};
}}
QLabel {{
    color: {TEXT};
}}
QSplitter::handle {{
    background-color: {BORDER};
}}
QDialog {{
    background-color: {MATTE_BLACK};
    color: {TEXT};
}}
QToolTip {{
    background-color: {SURFACE_BLACK};
    color: {ASTRO_BLUE};
    border: 1px solid {ASTRO_BLUE};
}}
"""


# ---------------------------------------------------------------------------
# Colormaps (DS9-style "Color" choices), rendered as 256-entry uint8 LUTs
# ---------------------------------------------------------------------------
_CMAP_SOURCE = {
    "Grayscale": "gray",
    "Inverted Gray": "gray_r",
    "Astro Blue": "cool",
    "Heat": "inferno",
    "Viridis": "viridis",
}
COLORMAP_NAMES = list(_CMAP_SOURCE.keys())


@functools.lru_cache(maxsize=None)
def colormap_lut(display_name):
    """Return a (256, 3) uint8 RGB lookup table for the given display name."""
    mpl_name = _CMAP_SOURCE.get(display_name, "gray")
    try:
        import matplotlib
        try:
            cmap = matplotlib.colormaps[mpl_name]
        except Exception:
            import matplotlib.cm as cm
            cmap = cm.get_cmap(mpl_name, 256)
        lut = (np.asarray(cmap(np.linspace(0.0, 1.0, 256)))[:, :3] * 255).astype(np.uint8)
    except Exception:
        # Fallback: plain linear grayscale ramp if matplotlib is unavailable.
        ramp = np.linspace(0, 255, 256).astype(np.uint8)
        lut = np.stack([ramp, ramp, ramp], axis=1)
    return lut


# ---------------------------------------------------------------------------
# Smooth animated toggle button (used for Fit/FITS/CSV style indicators)
# ---------------------------------------------------------------------------
class AnimatedToggleButton(QtWidgets.QPushButton):
    """A checkable button that eases its background between matte black
    (unchecked) and cosmic blue (checked), instead of snapping instantly."""

    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self.setCheckable(True)
        self.setCursor(QtCore.Qt.PointingHandCursor)
        self._bg = QtGui.QColor(SURFACE_BLACK)
        self._anim = QtCore.QPropertyAnimation(self, b"bgColor", self)
        self._anim.setDuration(180)
        self._anim.setEasingCurve(QtCore.QEasingCurve.OutCubic)
        self.toggled.connect(self._animate_to)

    def _animate_to(self, checked):
        target = QtGui.QColor(COSMIC_BLUE) if checked else QtGui.QColor(SURFACE_BLACK)
        self._anim.stop()
        self._anim.setStartValue(self._bg)
        self._anim.setEndValue(target)
        self._anim.start()

    def _get_bg_color(self):
        return self._bg

    def _set_bg_color(self, color):
        self._bg = color
        self.update()

    bgColor = QtCore.pyqtProperty(QtGui.QColor, _get_bg_color, _set_bg_color)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        rect = QtCore.QRectF(self.rect()).adjusted(1, 1, -1, -1)

        painter.setBrush(self._bg)
        border = QtGui.QColor(COSMIC_BLUE) if self.isChecked() else QtGui.QColor(BORDER)
        if self.underMouse() and not self.isChecked():
            border = QtGui.QColor(ASTRO_BLUE)
        painter.setPen(QtGui.QPen(border, 1))
        painter.drawRoundedRect(rect, 6, 6)

        text_color = QtGui.QColor("white") if self.isChecked() else QtGui.QColor(ASTRO_BLUE)
        painter.setPen(text_color)
        painter.drawText(rect, QtCore.Qt.AlignCenter, self.text())
        painter.end()
