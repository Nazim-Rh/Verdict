"""Sliding-window in-memory cutout cache.

Rather than caching rendered PNGs, this keeps the raw cropped cutout
arrays (plus each one's own WCS) in memory around the row currently
being viewed: a few rows behind (for quick "go back and recheck"), and a
batch of rows ahead (pre-cropped in the background so browsing forward
feels instant). Anything that falls outside the window is dropped to
keep memory usage bounded.

Keeping the raw array (instead of a rendered image) is what lets the GUI
change colormap / scale / contrast live: those are display parameters
applied at paint time by classifier.image_view.FitsImageView, not baked
into the cache.
"""
import threading

from .cutout import extract_cutout


class CutoutCacheManager:
    def __init__(self, data, wcs, get_coords, settings, coord_mode="wcs"):
        """
        data : 2D numpy array, the FITS image
        wcs : astropy WCS for `data`
        get_coords : callable(df_index) -> (ra, dec) or (x, y), depending
                     on coord_mode
        coord_mode : "wcs" (get_coords returns RA/Dec in degrees) or
                     "xy" (get_coords returns pixel X/Y directly, used
                     when the image has no usable WCS)
        settings : dict (see classifier.config.DEFAULTS) - read live, so
                   changing settings["box_size"] etc. takes effect on the
                   next generated cutout. Call clear() after changing a
                   setting that affects the crop itself (box_size,
                   smoothing) so existing cutouts are recropped.
        """
        self.data = data
        self.wcs = wcs
        self.get_coords = get_coords
        self.coord_mode = coord_mode
        self.settings = settings
        self._lock = threading.Lock()
        self._cache = {}      # df_index -> (cutout_data, cutout_wcs)
        self._pending = set()

    # -- lookup --------------------------------------------------------
    def is_cached(self, df_index):
        with self._lock:
            return df_index in self._cache

    # -- generation ------------------------------------------------------
    def generate_sync(self, df_index):
        """Return (cutout_data, cutout_wcs) for one row, cropping it first
        if it isn't already cached. Safe to call from any thread; safe to
        call repeatedly (no-op if already cached)."""
        with self._lock:
            cached = self._cache.get(df_index)
        if cached is not None:
            return cached

        a, b = self.get_coords(df_index)
        kwargs = {"x": a, "y": b} if self.coord_mode == "xy" else {"ra": a, "dec": b}
        cutout_data, cutout_wcs = extract_cutout(
            self.data, self.wcs,
            box_size=self.settings["box_size"],
            smoothing_enabled=self.settings.get("smoothing_enabled", True),
            smoothing_size=self.settings.get("smoothing_size", 3),
            **kwargs,
        )
        result = (cutout_data, cutout_wcs)
        with self._lock:
            self._cache[df_index] = result
        return result

    # kept as an alias: reads clearly at call sites that just want the array
    get_array = generate_sync

    # -- window bookkeeping ------------------------------------------------
    def window_indices(self, order, position):
        """`order`: list of df indices in the current view/sort order.
        `position`: position of the current row within `order`.
        Returns the set of df indices that should remain cached."""
        ahead = int(self.settings["cache_ahead"])
        behind = int(self.settings["cache_behind"])
        lo = max(0, position - behind)
        hi = min(len(order) - 1, position + ahead)
        return set(order[lo:hi + 1])

    def prune(self, keep):
        """Drop cached cutouts whose df index is not in `keep`."""
        with self._lock:
            for idx in list(self._cache.keys()):
                if idx not in keep:
                    del self._cache[idx]

    def ensure_window(self, order, position, submit_async):
        """Keep only `window_indices(order, position)` cached: prune
        anything outside the window, and asynchronously crop anything
        inside the window that's missing (except the current row, which
        the caller is expected to have generated synchronously already).

        `submit_async(job)` should schedule `job` (a zero-arg callable) to
        run on a background thread/pool.
        """
        keep = self.window_indices(order, position)
        self.prune(keep)

        current_index = order[position]
        for idx in keep:
            if idx == current_index or self.is_cached(idx):
                continue
            with self._lock:
                if idx in self._pending:
                    continue
                self._pending.add(idx)

            def job(i=idx):
                try:
                    self.generate_sync(i)
                finally:
                    with self._lock:
                        self._pending.discard(i)

            submit_async(job)

    def clear(self):
        """Drop every cached cutout (e.g. after changing box_size or
        smoothing, which affect the crop itself)."""
        with self._lock:
            self._cache.clear()
