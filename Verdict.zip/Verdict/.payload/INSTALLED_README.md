# Verdict

Verdict is a desktop app with two independent modes:

- **Judge Mode** — quickly classify astronomical detections as real,
  fake, or uncertain, by eye, from a cutout image centred on each
  source's position.
- **Crossmatch Mode** — match two catalogue tables against each other
  by sky position or pixel position, and save the matched result.

## Running Verdict

Double-click **Verdict** on your Desktop, or from a terminal:

```bash
./Verdict.sh
```

Switch between modes using the tabs at the top of the window.

## Judge Mode

1. Open the **Image (FITS)** and the **Table (FITS/CSV)** buttons in the
   top-right corner — in either order, it doesn't matter which you load
   first. The table can be a CSV or a FITS table.
2. When the table loads, confirm its columns in the dialog that appears:
   - **Position from: WCS (RA/Dec)** (default) — pick the RA and Dec
     columns; positions are projected onto the image using its WCS.
   - **Position from: Pixel (X/Y)** — pick the X and Y columns instead.
     Use this if the image has no usable WCS (e.g. you saw a
     "WCS projection failed" error), or if your catalogue only has
     pixel coordinates.
   - Pick a magnitude column too, if you want to sort by it.
3. The catalogue appears as a table on the left. Use **Sort Mag ↑ / Sort
   Mag ↓** to sort by magnitude.
4. Click any row — its cutout appears on the right, scaled with a
   2nd/98th percentile stretch, with a red aperture circle at the source
   position.
5. Classify with the keyboard (or the on-screen buttons):

   | Key            | Action                                       |
   |----------------|-----------------------------------------------|
   | `←` or `A`     | mark **fake**, advance to the next row        |
   | `→` or `D`     | mark **real**, advance to the next row        |
   | `↓` or `S`     | mark **uncertain**, advance to the next row   |
   | `↑`            | go back to the previous row                   |

   Verdicts are written continuously to `<table name>_classified.csv`
   next to the table you opened. Re-opening the same table later resumes
   any verdicts already saved.

### Settings

The ⚙ button (or **Settings → Cutout settings...**) lets you change box
size, aperture radius, scale percentiles, and cache look-ahead/behind —
at any time.

## Crossmatch Mode

Match two catalogue tables (each CSV or FITS) against each other,
independently of Judge mode — no image is needed here.

1. Click **Open table** under **Table A** and **Table B** to load each
   catalogue.
2. Set the **Radius** and its unit:
   - **arcsec** (default, `1.5`) — matches by RA/Dec using the true
     spherical angular separation between points on the sky.
   - **pixel** — matches by straight-line (Euclidean) distance between
     X/Y pixel positions. Use this when one or both tables don't have
     reliable sky coordinates.
3. Choose the **Match type**:
   - **One-to-one (best match)** (default) — each row of Table A is
     paired with at most one row of Table B, and vice versa; closest
     pairs are matched first.
   - **One-to-many** — Table A rows stay unique (each used at most
     once), but a Table B row may be matched to several Table A rows.
   - **Many-to-one** — the reverse: Table B rows stay unique, Table A
     rows may repeat.
4. Click **Run crossmatch**. You'll be asked to confirm the RA/Dec (or
   X/Y) columns for each table, then the matched rows appear below, with
   a `separation_arcsec` or `separation_px` column added. Columns from
   each input table are suffixed `_1` (Table A) and `_2` (Table B) to
   keep same-named columns apart.
6. It will give three tables:
   - **Matched A & B** (default) — Rows in both Table A & B.
   - **Table A only** — Rows in Table A but not in Table B.
   - **Table B only** — Rows in Table B but not in Table A.
5. Click **Save matched table...** to save the selected table as CSV or FITS.

## Notes

- Verdict only reads the files you open; it never modifies your original
  tables or images.
- Any table with recognizable RA/Dec or X/Y (and, for sorting in Judge
  Mode, magnitude) columns works — it doesn't need to come from any
  particular pipeline.
- for any queries contact at knnazimrh@gmail.com

## References

Verdict is built on top of the following open-source packages:

- **NumPy** — Harris, C.R., Millman, K.J., van der Walt, S.J. et al.
  "Array programming with NumPy." *Nature* 585, 357–362 (2020).
  https://doi.org/10.1038/s41586-020-2649-2
- **pandas** — McKinney, W. "Data Structures for Statistical Computing
  in Python." *Proceedings of the 9th Python in Science Conference*,
  51–56 (2010). https://doi.org/10.25080/Majora-92bf1922-00a
- **Astropy** — Astropy Collaboration et al. "The Astropy Project:
  Sustaining and Growing a Community-oriented Open-source Project and
  the Latest Major Release (v5.0)." *ApJ* 935, 167 (2022).
  https://doi.org/10.3847/1538-4357/ac7c74
- **SciPy** — Virtanen, P., Gommers, R., Oliphant, T.E. et al. "SciPy
  1.0: Fundamental Algorithms for Scientific Computing in Python."
  *Nature Methods* 17, 261–272 (2020).
  https://doi.org/10.1038/s41592-019-0686-2
- **Matplotlib** — Hunter, J. D. "Matplotlib: A 2D Graphics
  Environment." *Computing in Science & Engineering* 9, 90–95 (2007).
  https://doi.org/10.1109/MCSE.2007.55
- **PyQt5** — Riverbank Computing Limited.
  https://www.riverbankcomputing.com/software/pyqt/

If you use Verdict in a publication, please cite the packages above
that you relied on (e.g. crossmatching and coordinate handling use
Astropy and SciPy; the cutout display uses NumPy and Matplotlib).

for any queries contact knnazimrh@gmail.com
