#!/usr/bin/env bash
# Verdict launcher.
# This is the only script you need to touch — everything else this app
# needs lives in the hidden ".verdict" folder next to this file.
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR/.verdict"
source .venv/bin/activate
python3 run_classifier.py
