"""Persistent user settings for the Verdict classifier GUI.

Settings are stored as JSON in ~/.verdict/settings.json and are
editable from the Settings dialog inside the app (Ctrl+,).
"""
import json
import os

SETTINGS_DIR = os.path.join(os.path.expanduser("~"), ".verdict")
SETTINGS_PATH = os.path.join(SETTINGS_DIR, "settings.json")

DEFAULTS = {
    "box_size": 20,          # cutout side length, in pixels
    "aperture_radius": 3.0,  # aperture circle radius, in pixels
    "pct_low": 2.0,          # lower percentile used for the display min/max scale
    "pct_high": 98.0,        # upper percentile used for the display min/max scale
    "cache_ahead": 10,       # rows ahead of the current row to pre-generate
    "cache_behind": 6,       # rows behind the current row to keep cached
    "cmap": "gray",          # legacy matplotlib colormap name (make_cutout_png only)
    "smoothing_enabled": True,   # whether to smooth the cutout before display
    "smoothing_size": 3,         # median filter kernel size (pixels, odd)
    "cmap_display": "Grayscale",   # live-view color map (see classifier.theme)
    "scale_func_display": "Linear",  # live-view scale function (Linear/Log/Sqrt/Squared)
}


def load_settings():
    """Return the saved settings merged over the defaults."""
    settings = dict(DEFAULTS)
    if os.path.exists(SETTINGS_PATH):
        try:
            with open(SETTINGS_PATH) as f:
                saved = json.load(f)
            for k, v in saved.items():
                if k in DEFAULTS:
                    settings[k] = v
        except Exception:
            pass
    return settings


def save_settings(settings):
    """Persist the given settings dict (only known keys) to disk."""
    os.makedirs(SETTINGS_DIR, exist_ok=True)
    to_save = {k: settings[k] for k in DEFAULTS if k in settings}
    with open(SETTINGS_PATH, "w") as f:
        json.dump(to_save, f, indent=2)
