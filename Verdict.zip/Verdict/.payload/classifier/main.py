#!/usr/bin/env python3
"""Verdict — astronomical detection classifier.

Two independent tabs: Judge Mode (this workflow) and Crossmatch Mode
(see classifier.crossmatch), which matches two tables against each
other and has nothing to do with the image below.

Judge Mode workflow:
  1. Open the Image (FITS) and the Table (FITS/CSV) with RA/Dec (or
     X/Y, if the image has no usable WCS) columns, in either order.
     Confirm/adjust the columns in the dialog that appears when the
     table loads.
  3. The table appears on the left (sortable by magnitude, ascending or
     descending). Click a row, or use it after sorting, and its cutout PNG
     appears on the right, generated on demand.
  4. Classify with the keyboard:
        Left / A   -> fake
        Right / D  -> real
        Down / S   -> uncertain
        Up         -> go back to the previous row (to recheck / re-classify)
     Marking a verdict auto-advances to the next row in the current sort
     order. Verdicts are saved continuously to "<csvname>_classified.csv"
     next to the CSV.
  5. The cutout panel is a live, DS9-style view: it renders the raw pixel
     data directly, so the color map, scale function, and contrast can be
     changed on the fly with no re-crop. Hovering over the image reports
     the pixel value and WCS position under the cursor, just like DS9's
     info bar. Cropped cutouts are cached in memory in a sliding window
     around the row you're on (a batch ahead of you, a few kept behind)
     -- older ones are dropped automatically to keep memory usage bounded.
"""
import os
import sys

import numpy as np
import pandas as pd
from astropy.io import fits
from astropy.wcs import WCS
from astropy.coordinates import SkyCoord
import astropy.units as u

from PyQt5 import QtCore, QtGui, QtWidgets

# Path to the app icon (dropped in by the installer next to the classifier
# code, at ../assets/verdict.png). Falls back gracefully if it's missing.
_ICON_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "verdict.png")


def _app_icon():
    if os.path.isfile(_ICON_PATH):
        return QtGui.QIcon(_ICON_PATH)
    return QtGui.QIcon()


def _readme_text():
    """Locate the user-facing README next to the installed app (or, in a
    dev checkout, next to the installer) and return its contents. Tries a
    few plausible locations so it works both installed and unpacked."""
    base = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(base, "..", "INSTALLED_README.md"),  # dev checkout: .payload/INSTALLED_README.md
        os.path.join(base, "..", "..", "README.md"),   # installed: <install dir>/README.md
        os.path.join(base, "..", "README.md"),
    ]
    for path in candidates:
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return f.read()
            except Exception:
                continue
    return "# Verdict\n\nNo README.md was found alongside the app."

from . import config as cfg
from . import theme
from .cache_manager import CutoutCacheManager
from .columns import guess_columns, guess_xy
from .image_view import FitsImageView
from .crossmatch import CrossmatchWidget

VERDICT_LABELS = {"fake": "Fake", "real": "Real", "uncertain": "Uncertain"}


# ---------------------------------------------------------------------------
# Background job runner (QThreadPool wrapper around a plain callable)
# ---------------------------------------------------------------------------
class _JobSignal(QtCore.QObject):
    finished = QtCore.pyqtSignal()
    error = QtCore.pyqtSignal(str)


class _Runnable(QtCore.QRunnable):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn
        self.signals = _JobSignal()

    def run(self):
        # Never let an exception escape into Qt's thread pool: PyQt aborts
        # the whole process if that happens. Report it instead.
        try:
            self.fn()
        except Exception as e:
            self.signals.error.emit(str(e))
        finally:
            self.signals.finished.emit()


# ---------------------------------------------------------------------------
# Column-mapping dialog, shown whenever a CSV is opened
# ---------------------------------------------------------------------------
class ColumnMapDialog(QtWidgets.QDialog):
    def __init__(self, columns, guess_ra, guess_dec, guess_mag,
                 guess_x=None, guess_y=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Confirm columns")
        layout = QtWidgets.QFormLayout(self)

        self.wcs_radio = QtWidgets.QRadioButton("WCS (RA / Dec)")
        self.xy_radio = QtWidgets.QRadioButton("Pixel (X / Y)")
        self.wcs_radio.setChecked(True)
        mode_row = QtWidgets.QHBoxLayout()
        mode_row.addWidget(self.wcs_radio)
        mode_row.addWidget(self.xy_radio)
        layout.addRow("Position from:", mode_row)

        self.ra_combo = QtWidgets.QComboBox()
        self.dec_combo = QtWidgets.QComboBox()
        self.x_combo = QtWidgets.QComboBox()
        self.y_combo = QtWidgets.QComboBox()
        self.mag_combo = QtWidgets.QComboBox()
        for combo in (self.ra_combo, self.dec_combo, self.x_combo,
                      self.y_combo, self.mag_combo):
            combo.addItems(columns)

        if guess_ra in columns:
            self.ra_combo.setCurrentText(guess_ra)
        if guess_dec in columns:
            self.dec_combo.setCurrentText(guess_dec)
        if guess_mag in columns:
            self.mag_combo.setCurrentText(guess_mag)
        if guess_x in columns:
            self.x_combo.setCurrentText(guess_x)
        if guess_y in columns:
            self.y_combo.setCurrentText(guess_y)

        layout.addRow("RA column:", self.ra_combo)
        layout.addRow("Dec column:", self.dec_combo)
        layout.addRow("X column:", self.x_combo)
        layout.addRow("Y column:", self.y_combo)
        layout.addRow("Magnitude column (for sorting):", self.mag_combo)

        self._set_xy_visible(False)
        self.wcs_radio.toggled.connect(lambda on: self._set_xy_visible(not on))

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def _set_xy_visible(self, xy_visible):
        for combo in (self.ra_combo, self.dec_combo):
            combo.setVisible(not xy_visible)
            self.layout().labelForField(combo).setVisible(not xy_visible)
        for combo in (self.x_combo, self.y_combo):
            combo.setVisible(xy_visible)
            self.layout().labelForField(combo).setVisible(xy_visible)

    def result_columns(self):
        """Returns (coord_mode, ra_col, dec_col, x_col, y_col, mag_col).
        coord_mode is "wcs" or "xy"; the unused pair is returned as-is but
        should be ignored by the caller."""
        mode = "wcs" if self.wcs_radio.isChecked() else "xy"
        return (mode, self.ra_combo.currentText(), self.dec_combo.currentText(),
                self.x_combo.currentText(), self.y_combo.currentText(),
                self.mag_combo.currentText())


# ---------------------------------------------------------------------------
# Settings dialog
# ---------------------------------------------------------------------------
class SettingsDialog(QtWidgets.QDialog):
    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Cutout settings")
        self.settings = dict(settings)
        layout = QtWidgets.QFormLayout(self)

        self.box_spin = QtWidgets.QSpinBox()
        self.box_spin.setRange(4, 500)
        self.box_spin.setValue(int(settings["box_size"]))
        layout.addRow("Box size (pixels):", self.box_spin)

        self.aper_spin = QtWidgets.QDoubleSpinBox()
        self.aper_spin.setRange(0.5, 100.0)
        self.aper_spin.setSingleStep(0.5)
        self.aper_spin.setValue(float(settings["aperture_radius"]))
        layout.addRow("Aperture radius (pixels):", self.aper_spin)

        self.pct_low_spin = QtWidgets.QDoubleSpinBox()
        self.pct_low_spin.setRange(0.0, 49.0)
        self.pct_low_spin.setValue(float(settings["pct_low"]))
        layout.addRow("Scale low percentile:", self.pct_low_spin)

        self.pct_high_spin = QtWidgets.QDoubleSpinBox()
        self.pct_high_spin.setRange(51.0, 100.0)
        self.pct_high_spin.setValue(float(settings["pct_high"]))
        layout.addRow("Scale high percentile:", self.pct_high_spin)

        self.smoothing_check = QtWidgets.QCheckBox("Smooth cutout (median filter)")
        self.smoothing_check.setChecked(bool(settings.get("smoothing_enabled", True)))
        layout.addRow(self.smoothing_check)

        self.smoothing_spin = QtWidgets.QSpinBox()
        self.smoothing_spin.setRange(1, 25)
        self.smoothing_spin.setSingleStep(2)
        self.smoothing_spin.setValue(int(settings.get("smoothing_size", 3)))
        self.smoothing_spin.setToolTip(
            "Median filter kernel size, in pixels. Use an odd value "
            "(e.g. 3, 5, 7) so the filter is centered on each pixel.")
        layout.addRow("Median filter size (px):", self.smoothing_spin)

        self.smoothing_check.toggled.connect(self.smoothing_spin.setEnabled)
        self.smoothing_spin.setEnabled(self.smoothing_check.isChecked())

        self.ahead_spin = QtWidgets.QSpinBox()
        self.ahead_spin.setRange(1, 200)
        self.ahead_spin.setValue(int(settings["cache_ahead"]))
        layout.addRow("Rows to pre-cache ahead:", self.ahead_spin)

        self.behind_spin = QtWidgets.QSpinBox()
        self.behind_spin.setRange(0, 200)
        self.behind_spin.setValue(int(settings["cache_behind"]))
        layout.addRow("Rows to keep cached behind:", self.behind_spin)

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def result_settings(self):
        self.settings["box_size"] = self.box_spin.value()
        self.settings["aperture_radius"] = self.aper_spin.value()
        self.settings["pct_low"] = self.pct_low_spin.value()
        self.settings["pct_high"] = self.pct_high_spin.value()
        self.settings["smoothing_enabled"] = self.smoothing_check.isChecked()
        self.settings["smoothing_size"] = self.smoothing_spin.value()
        self.settings["cache_ahead"] = self.ahead_spin.value()
        self.settings["cache_behind"] = self.behind_spin.value()
        return self.settings


# ---------------------------------------------------------------------------
# Table widget with custom key handling (so Left/Right/Down/Up/A/D/S drive
# classification instead of native cell navigation)
# ---------------------------------------------------------------------------
class ClassifierTable(QtWidgets.QTableWidget):
    keyAction = QtCore.pyqtSignal(str)

    _KEY_MAP = {
        QtCore.Qt.Key_Left: "fake",
        QtCore.Qt.Key_A: "fake",
        QtCore.Qt.Key_Right: "real",
        QtCore.Qt.Key_D: "real",
        QtCore.Qt.Key_Down: "uncertain",
        QtCore.Qt.Key_S: "uncertain",
        QtCore.Qt.Key_Up: "back",
    }

    def keyPressEvent(self, event):
        action = self._KEY_MAP.get(event.key())
        if action is not None:
            self.keyAction.emit(action)
            event.accept()
            return
        super().keyPressEvent(event)


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Verdict")
        self.setWindowIcon(_app_icon())
        self.resize(1300, 800)

        self.settings = cfg.load_settings()
        self.threadpool = QtCore.QThreadPool.globalInstance()

        # state
        self.fits_path = None
        self.image_data = None
        self.wcs = None
        self._last_dir = os.path.expanduser("~")

        self.df = None
        self.coord_mode = "wcs"
        self.ra_col = self.dec_col = self.mag_col = None
        self.x_col = self.y_col = None
        self.order = []          # list of df indices, current view order
        self.sort_ascending = True
        self.cache = None
        self.classified_csv_path = None
        self.current_index = None      # df index currently displayed
        self.visit_history = []        # df indices, in navigation order
        self.nav_position = -1

        # Zoom/pan/display-scale state (fit-to-panel vs fixed pct, colormap,
        # scale function, contrast) all live on self.image_view itself.

        self._save_timer = QtCore.QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(self._do_save)

        self._build_ui()

    # ------------------------------------------------------------------
    def _build_ui(self):
        # Outer container: a global title bar (VERDICT + readme button, seen
        # no matter which tab is active) on top, with the Judge/Crossmatch
        # tab widget filling the rest of the window underneath it.
        outer_widget = QtWidgets.QWidget()
        outer_layout = QtWidgets.QVBoxLayout(outer_widget)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)
        self.setCentralWidget(outer_widget)

        title_bar = QtWidgets.QHBoxLayout()
        title_bar.setContentsMargins(10, 6, 10, 6)
        title_label = QtWidgets.QLabel("VERDICT")
        title_label.setStyleSheet(
            f"color: {theme.ASTRO_BLUE}; font-weight: 600; font-size: 13px; "
            "letter-spacing: 1px;")
        title_bar.addWidget(title_label)
        title_bar.addStretch(1)

        # Global "i" readme/help button, always visible in the title bar
        # (not tied to either tab, so it stays put no matter which is active).
        self.readme_btn = QtWidgets.QPushButton()
        self.readme_btn.setIcon(
            self.style().standardIcon(QtWidgets.QStyle.SP_MessageBoxInformation))
        self.readme_btn.setIconSize(QtCore.QSize(14, 14))
        self.readme_btn.setFixedSize(24, 22)
        self.readme_btn.setToolTip("Open the readme / usage instructions")
        self.readme_btn.setCursor(QtCore.Qt.PointingHandCursor)
        self.readme_btn.clicked.connect(self.show_readme)
        title_bar.addWidget(self.readme_btn)

        outer_layout.addLayout(title_bar)

        tabs = QtWidgets.QTabWidget()
        tabs.setElideMode(QtCore.Qt.ElideNone)
        outer_layout.addWidget(tabs, 1)

        judge_widget = QtWidgets.QWidget()
        main_layout = QtWidgets.QVBoxLayout(judge_widget)

        # header row: Save / Close Table in the top-left corner, quick
        # FITS/CSV/Settings access in the top-right corner (File/Settings
        # menus are gone -- these buttons replace them)
        header_row = QtWidgets.QHBoxLayout()

        self.save_corner_btn = QtWidgets.QPushButton("Save")
        self.save_corner_btn.setFixedSize(80, 30)
        self.save_corner_btn.setToolTip("Save classified table")
        self.save_corner_btn.clicked.connect(self._do_save)
        header_row.addWidget(self.save_corner_btn)

        self.close_table_btn = QtWidgets.QPushButton("Close Table")
        self.close_table_btn.setFixedSize(110, 30)
        self.close_table_btn.setToolTip("Close the currently loaded table")
        self.close_table_btn.clicked.connect(self.close_table)
        header_row.addWidget(self.close_table_btn)

        header_row.addStretch(1)

        self.fits_corner_btn = theme.AnimatedToggleButton("Image (FITS)")
        self.fits_corner_btn.setFixedSize(110, 30)
        self.fits_corner_btn.setToolTip("Open a FITS image")
        self.fits_corner_btn.clicked.connect(self._on_fits_corner_clicked)
        header_row.addWidget(self.fits_corner_btn)

        self.csv_corner_btn = theme.AnimatedToggleButton("Table (FITS/CSV)")
        self.csv_corner_btn.setFixedSize(130, 30)
        self.csv_corner_btn.setToolTip("Open a catalogue table (FITS or CSV)")
        self.csv_corner_btn.clicked.connect(self._on_csv_corner_clicked)
        header_row.addWidget(self.csv_corner_btn)

        self.settings_corner_btn = QtWidgets.QPushButton("\u2699")
        self.settings_corner_btn.setFixedSize(34, 30)
        self.settings_corner_btn.setToolTip("Cutout settings")
        self.settings_corner_btn.clicked.connect(self.edit_settings)
        header_row.addWidget(self.settings_corner_btn)

        main_layout.addLayout(header_row)

        # toolbar row: sort buttons
        tool_row = QtWidgets.QHBoxLayout()
        self.sort_asc_btn = QtWidgets.QPushButton("Sort Mag \u2191 (ascending)")
        self.sort_desc_btn = QtWidgets.QPushButton("Sort Mag \u2193 (descending)")
        self.sort_asc_btn.clicked.connect(lambda: self.sort_by_mag(True))
        self.sort_desc_btn.clicked.connect(lambda: self.sort_by_mag(False))
        tool_row.addWidget(self.sort_asc_btn)
        tool_row.addWidget(self.sort_desc_btn)

        # zoom controls (DS9-style: zoom in/out, fit-to-panel, native size)
        tool_row.addSpacing(20)
        tool_row.addWidget(QtWidgets.QLabel("Zoom:"))
        self.zoom_out_btn = QtWidgets.QPushButton("\u2212")
        self.zoom_out_btn.setFixedWidth(28)
        self.zoom_out_btn.setToolTip("Zoom out")
        self.zoom_out_btn.clicked.connect(self.zoom_out)
        tool_row.addWidget(self.zoom_out_btn)

        self.zoom_level_label = QtWidgets.QLabel("Fit")
        self.zoom_level_label.setAlignment(QtCore.Qt.AlignCenter)
        self.zoom_level_label.setFixedWidth(48)
        tool_row.addWidget(self.zoom_level_label)

        self.zoom_in_btn = QtWidgets.QPushButton("+")
        self.zoom_in_btn.setFixedWidth(32)
        self.zoom_in_btn.setToolTip("Zoom in")
        self.zoom_in_btn.clicked.connect(self.zoom_in)
        tool_row.addWidget(self.zoom_in_btn)

        self.zoom_fit_btn = theme.AnimatedToggleButton("Fit")
        self.zoom_fit_btn.setFixedSize(48, 26)
        self.zoom_fit_btn.setChecked(True)
        self.zoom_fit_btn.setToolTip("Fit cutout to the panel")
        self.zoom_fit_btn.clicked.connect(self.zoom_fit)
        tool_row.addWidget(self.zoom_fit_btn)

        self.zoom_100_btn = QtWidgets.QPushButton("100%")
        self.zoom_100_btn.setToolTip("Show the cutout at its native pixel size")
        self.zoom_100_btn.clicked.connect(lambda: self.set_zoom(100))
        tool_row.addWidget(self.zoom_100_btn)

        # contrast controls (DS9-style scale limits: narrows/widens the
        # pct_low/pct_high percentile window used for display min/max)
        tool_row.addSpacing(20)
        tool_row.addWidget(QtWidgets.QLabel("Contrast:"))
        self.contrast_out_btn = QtWidgets.QPushButton("\u2212")
        self.contrast_out_btn.setFixedWidth(28)
        self.contrast_out_btn.setToolTip("Lower contrast (widen the scale limits)")
        self.contrast_out_btn.clicked.connect(self.contrast_decrease)
        tool_row.addWidget(self.contrast_out_btn)

        self.contrast_level_label = QtWidgets.QLabel("")
        self.contrast_level_label.setAlignment(QtCore.Qt.AlignCenter)
        self.contrast_level_label.setFixedWidth(70)
        tool_row.addWidget(self.contrast_level_label)

        self.contrast_in_btn = QtWidgets.QPushButton("+")
        self.contrast_in_btn.setFixedWidth(28)
        self.contrast_in_btn.setToolTip("Raise contrast (narrow the scale limits)")
        self.contrast_in_btn.clicked.connect(self.contrast_increase)
        tool_row.addWidget(self.contrast_in_btn)

        self.contrast_reset_btn = QtWidgets.QPushButton("Reset")
        self.contrast_reset_btn.setToolTip("Reset contrast to the default scale limits")
        self.contrast_reset_btn.clicked.connect(self.contrast_reset)
        tool_row.addWidget(self.contrast_reset_btn)
        self._update_contrast_label()

        # smoothing toggle, easily reachable without opening Settings
        tool_row.addSpacing(20)
        self.smooth_check = QtWidgets.QCheckBox("Smoothing")
        self.smooth_check.setToolTip(
            "Toggle the median-filter smoothing applied to cutouts "
            "(same option as Settings \u2192 Cutout settings...).")
        self.smooth_check.setChecked(bool(self.settings.get("smoothing_enabled", True)))
        self.smooth_check.toggled.connect(self.toggle_smoothing)
        tool_row.addWidget(self.smooth_check)

        # color map + scale function (DS9-style "Color" / "Scale" menus) --
        # these redraw the live cutout instantly, no re-crop needed
        tool_row.addSpacing(20)
        tool_row.addWidget(QtWidgets.QLabel("Color:"))
        self.cmap_combo = QtWidgets.QComboBox()
        self.cmap_combo.addItems(theme.COLORMAP_NAMES)
        self.cmap_combo.setCurrentText(
            self.settings.get("cmap_display", "Grayscale"))
        self.cmap_combo.currentTextChanged.connect(self._on_display_settings_changed)
        tool_row.addWidget(self.cmap_combo)

        tool_row.addWidget(QtWidgets.QLabel("Scale:"))
        self.scale_combo = QtWidgets.QComboBox()
        self.scale_combo.addItems(["Linear", "Log", "Sqrt", "Squared"])
        self.scale_combo.setCurrentText(
            self.settings.get("scale_func_display", "Linear"))
        self.scale_combo.currentTextChanged.connect(self._on_display_settings_changed)
        tool_row.addWidget(self.scale_combo)

        tool_row.addStretch(1)
        self.status_label = QtWidgets.QLabel("No CSV loaded")
        tool_row.addWidget(self.status_label)
        main_layout.addLayout(tool_row)

        splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        main_layout.addWidget(splitter, 1)

        # left: table
        self.table = ClassifierTable()
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSortingEnabled(False)  # we sort manually (see sort_by_mag)
        self.table.itemSelectionChanged.connect(self.on_selection_changed)
        self.table.keyAction.connect(self.on_key_action)
        splitter.addWidget(self.table)

        # right: image + info + buttons
        right_widget = QtWidgets.QWidget()
        right_layout = QtWidgets.QVBoxLayout(right_widget)

        self.image_view = FitsImageView()
        self.image_view.setStyleSheet(
            f"border: 1px solid {theme.BORDER}; border-radius: 4px;")
        self.image_view.pixelHover.connect(self._on_pixel_hover)
        self.image_view.hoverCleared.connect(self._on_hover_cleared)
        right_layout.addWidget(self.image_view, 1)

        # DS9-style readout bar: pixel value + WCS position under the cursor
        self.hover_label = QtWidgets.QLabel("Hover over the image to inspect a pixel")
        self.hover_label.setAlignment(QtCore.Qt.AlignCenter)
        self.hover_label.setStyleSheet(
            f"color: {theme.ASTRO_BLUE}; background-color: {theme.PANEL_BLACK}; "
            f"border: 1px solid {theme.BORDER}; border-radius: 4px; padding: 4px; "
            "font-family: Consolas, Menlo, monospace;")
        right_layout.addWidget(self.hover_label)

        self.info_label = QtWidgets.QLabel("")
        self.info_label.setAlignment(QtCore.Qt.AlignCenter)
        right_layout.addWidget(self.info_label)

        btn_row = QtWidgets.QHBoxLayout()
        self.fake_btn = QtWidgets.QPushButton("\u2190 Fake (A)")
        self.uncertain_btn = QtWidgets.QPushButton("\u2193 Uncertain (S)")
        self.real_btn = QtWidgets.QPushButton("Real (D) \u2192")
        self.back_btn = QtWidgets.QPushButton("\u2191 Back")
        self.fake_btn.clicked.connect(lambda: self.on_key_action("fake"))
        self.uncertain_btn.clicked.connect(lambda: self.on_key_action("uncertain"))
        self.real_btn.clicked.connect(lambda: self.on_key_action("real"))
        self.back_btn.clicked.connect(lambda: self.on_key_action("back"))
        for b in (self.fake_btn, self.uncertain_btn, self.real_btn, self.back_btn):
            btn_row.addWidget(b)
        right_layout.addLayout(btn_row)

        splitter.addWidget(right_widget)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)

        self._apply_display_settings()  # sync image_view to saved settings

        tabs.addTab(judge_widget, "Judge Mode")
        tabs.addTab(CrossmatchWidget(), "Crossmatch Mode")

        self.statusBar().showMessage("Open an image and a table, in either order, to begin.")

    # ------------------------------------------------------------------
    # Top-right corner buttons (quick FITS / CSV / Settings access)
    # ------------------------------------------------------------------
    def _on_fits_corner_clicked(self):
        self.open_fits_image()
        self.fits_corner_btn.setChecked(self.image_data is not None)

    def _on_csv_corner_clicked(self):
        self.open_csv()
        self.csv_corner_btn.setChecked(self.df is not None)

    # ------------------------------------------------------------------
    # Live display settings (color map / scale function / contrast) --
    # these only affect how the already-cropped cutout is drawn, so they
    # redraw instantly with no re-crop and no cache invalidation.
    # ------------------------------------------------------------------
    def _on_display_settings_changed(self, *_):
        self._apply_display_settings()

    def _apply_display_settings(self):
        cmap_name = self.cmap_combo.currentText()
        scale_name = self.scale_combo.currentText()
        self.settings["cmap_display"] = cmap_name
        self.settings["scale_func_display"] = scale_name
        cfg.save_settings(self.settings)
        self.image_view.set_display_settings(
            pct_low=self.settings["pct_low"],
            pct_high=self.settings["pct_high"],
            cmap_name=cmap_name,
            scale_func=scale_name,
        )

    # ------------------------------------------------------------------
    # Hover readout: pixel value + WCS position under the cursor (DS9-style)
    # ------------------------------------------------------------------
    def _on_pixel_hover(self, info):
        value = info.get("value")
        value_text = f"{value:.4g}" if np.isfinite(value) else "NaN"
        text = f"X: {info['x']}   Y: {info['y']}   Value: {value_text}"
        if "ra" in info and "dec" in info:
            coord = SkyCoord(ra=info["ra"] * u.deg, dec=info["dec"] * u.deg)
            text += "   " + coord.to_string("hmsdms", precision=2)
        self.hover_label.setText(text)

    def _on_hover_cleared(self):
        self.hover_label.setText("Hover over the image to inspect a pixel")

    # ------------------------------------------------------------------
    # FITS loading
    # ------------------------------------------------------------------
    def open_fits_image(self):
        fits_path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Open FITS image", self._last_dir,
            "FITS files (*.fits *.fit *.fits.gz);;All files (*)")
        if not fits_path:
            return

        try:
            with fits.open(fits_path) as hdul:
                header = hdul[0].header
                data = hdul[0].data.astype(float)
                wcs = WCS(header)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Error loading FITS", str(e))
            return

        self.fits_path = fits_path
        self.image_data = data
        self.wcs = wcs
        self._last_dir = os.path.dirname(fits_path)
        self.fits_corner_btn.setChecked(True)
        self.statusBar().showMessage(f"Loaded image: {os.path.basename(fits_path)}")
        self._maybe_start_session()

    # ------------------------------------------------------------------
    # Table loading (CSV or FITS table) -- order relative to the image
    # doesn't matter; the session starts once both are loaded.
    # ------------------------------------------------------------------
    def open_csv(self):
        csv_path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Open catalogue table", self._last_dir,
            "Table files (*.csv *.fits *.fit);;All files (*)")
        if not csv_path:
            return
        self._last_dir = os.path.dirname(csv_path)

        try:
            if csv_path.lower().endswith((".fits", ".fit")):
                from astropy.table import Table
                df = Table.read(csv_path).to_pandas()
            else:
                df = pd.read_csv(csv_path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Error reading table", str(e))
            return
        if df.empty:
            QtWidgets.QMessageBox.warning(self, "Empty table", "That table has no rows.")
            return
        df = df.reset_index(drop=True)

        guess_ra, guess_dec, guess_mag = guess_columns(list(df.columns))
        guess_x, guess_y = guess_xy(list(df.columns))
        dialog = ColumnMapDialog(list(df.columns), guess_ra, guess_dec, guess_mag,
                                  guess_x, guess_y, self)
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        coord_mode, ra_col, dec_col, x_col, y_col, mag_col = dialog.result_columns()

        if "verdict" not in df.columns:
            df["verdict"] = ""
        else:
            df["verdict"] = df["verdict"].fillna("")

        self.df = df
        self.coord_mode = coord_mode
        self.ra_col = ra_col
        self.dec_col = dec_col
        self.x_col = x_col
        self.y_col = y_col
        self.mag_col = mag_col
        self.csv_path = csv_path

        stem, ext = os.path.splitext(os.path.basename(csv_path))
        if stem.endswith("_classified"):
            self.classified_csv_path = csv_path
        else:
            self.classified_csv_path = os.path.join(
                os.path.dirname(csv_path), f"{stem}_classified.csv")
            if os.path.exists(self.classified_csv_path):
                # resume a previous classification session for this CSV
                try:
                    prev = pd.read_csv(self.classified_csv_path)
                    if len(prev) == len(df) and "verdict" in prev.columns:
                        df["verdict"] = prev["verdict"].fillna("")
                except Exception:
                    pass

        self.order = list(df.index)
        self.populate_table()
        self.csv_corner_btn.setChecked(True)
        self._maybe_start_session()

    def _maybe_start_session(self):
        """Start (or restart) browsing once both an image and a table are
        loaded, regardless of which was opened first."""
        if self.image_data is None or self.wcs is None or self.df is None:
            have = "table" if self.df is not None else "image"
            need = "an image" if self.df is not None else "a table"
            self.statusBar().showMessage(f"Loaded the {have} — open {need} to begin.")
            return

        self.cache = CutoutCacheManager(
            self.image_data, self.wcs, self._get_coords, self.settings,
            coord_mode=self.coord_mode)
        self.order = list(self.df.index)
        self.visit_history = []
        self.nav_position = -1
        self.current_index = None
        self.update_status()
        if self.order:
            self.navigate_to(self.order[0], record_history=True)

    def _get_coords(self, df_index):
        row = self.df.loc[df_index]
        if self.coord_mode == "xy":
            return float(row[self.x_col]), float(row[self.y_col])
        return float(row[self.ra_col]), float(row[self.dec_col])

    # ------------------------------------------------------------------
    # Table population / sorting
    # ------------------------------------------------------------------
    def populate_table(self):
        df = self.df
        columns = list(df.columns)
        self.table.blockSignals(True)
        self.table.clear()
        self.table.setColumnCount(len(columns))
        self.table.setHorizontalHeaderLabels(columns)
        self.table.setRowCount(len(self.order))
        for row, df_index in enumerate(self.order):
            for col, name in enumerate(columns):
                value = df.at[df_index, name]
                item = QtWidgets.QTableWidgetItem(str(value))
                item.setData(QtCore.Qt.UserRole, df_index)
                self.table.setItem(row, col, item)
        self.table.resizeColumnsToContents()
        self.table.blockSignals(False)

    def sort_by_mag(self, ascending):
        if self.df is None or self.mag_col not in self.df.columns:
            return
        self.sort_ascending = ascending
        self.order = list(
            self.df.sort_values(self.mag_col, ascending=ascending, kind="mergesort").index
        )
        self.populate_table()
        if self.current_index is not None:
            self._select_row_for_index(self.current_index)
        self.update_status()

    def _row_for_index(self, df_index):
        try:
            return self.order.index(df_index)
        except ValueError:
            return None

    def _select_row_for_index(self, df_index):
        row = self._row_for_index(df_index)
        if row is None:
            return
        self.table.blockSignals(True)
        self.table.selectRow(row)
        self.table.scrollToItem(self.table.item(row, 0))
        self.table.blockSignals(False)

    # ------------------------------------------------------------------
    # Selection / navigation
    # ------------------------------------------------------------------
    def on_selection_changed(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return
        row = rows[0].row()
        item = self.table.item(row, 0)
        if item is None:
            return
        df_index = item.data(QtCore.Qt.UserRole)
        if df_index == self.current_index:
            return
        self.navigate_to(df_index, record_history=True)

    def navigate_to(self, df_index, record_history):
        if self.cache is None:
            return
        position = self._row_for_index(df_index)
        if position is None:
            return

        self.current_index = df_index
        self._select_row_for_index(df_index)

        # generate + display the current cutout immediately (synchronous:
        # it's a single small image, fast enough to not block noticeably)
        try:
            cutout_data, cutout_wcs = self.cache.generate_sync(df_index)
            self.image_view.set_cutout(
                cutout_data, cutout_wcs, aperture_radius=self.settings["aperture_radius"])
        except Exception as e:
            self.image_view.clear()
            self.hover_label.setText(f"Cutout failed: {e}")

        row_data = self.df.loc[df_index]
        verdict = row_data.get("verdict", "") or "(unclassified)"
        mag_text = f"{row_data[self.mag_col]:.3f}" if self.mag_col in self.df.columns else "n/a"
        if self.coord_mode == "xy":
            pos_text = f"X={row_data[self.x_col]:.2f}  Y={row_data[self.y_col]:.2f}"
        else:
            pos_text = f"RA={row_data[self.ra_col]:.6f}  Dec={row_data[self.dec_col]:.6f}"
        self.info_label.setText(
            f"Row {position + 1} / {len(self.order)}   |   "
            f"{pos_text}   |   "
            f"Mag={mag_text}   |   Verdict: {verdict}"
        )

        if record_history:
            self.visit_history = self.visit_history[:self.nav_position + 1]
            self.visit_history.append(df_index)
            self.nav_position = len(self.visit_history) - 1

        def submit_async(job):
            runnable = _Runnable(job)
            runnable.signals.error.connect(
                lambda msg: self.statusBar().showMessage(
                    f"Background cutout error: {msg}", 5000))
            self.threadpool.start(runnable)

        self.cache.ensure_window(self.order, position, submit_async)
        self.update_status()

    def go_back(self):
        if self.nav_position <= 0:
            self.statusBar().showMessage("Already at the earliest visited row.", 3000)
            return
        self.nav_position -= 1
        df_index = self.visit_history[self.nav_position]
        self.navigate_to(df_index, record_history=False)

    # ------------------------------------------------------------------
    # Zoom (display scaling, like DS9's Zoom controls). The image view
    # renders live from the raw array, so zooming never needs a re-crop.
    # ------------------------------------------------------------------
    def zoom_in(self):
        self.image_view.zoom_in()
        self.zoom_fit_btn.setChecked(False)
        self.zoom_level_label.setText(self.image_view.current_zoom_label())

    def zoom_out(self):
        self.image_view.zoom_out()
        self.zoom_fit_btn.setChecked(False)
        self.zoom_level_label.setText(self.image_view.current_zoom_label())

    def zoom_fit(self):
        self.image_view.zoom_fit()
        self.zoom_fit_btn.setChecked(True)
        self.zoom_level_label.setText(self.image_view.current_zoom_label())

    def set_zoom(self, pct):
        self.image_view.set_zoom(pct)
        self.zoom_fit_btn.setChecked(False)
        self.zoom_level_label.setText(self.image_view.current_zoom_label())

    # ------------------------------------------------------------------
    # Contrast (display scale limits, like DS9's Scale > Limits). This is
    # a display-only parameter now, so it redraws instantly -- no cache
    # invalidation, no re-crop.
    # ------------------------------------------------------------------
    def contrast_increase(self):
        """Narrow the pct_low/pct_high window -> more contrast."""
        step = 2.0
        lo = self.settings["pct_low"] + step
        hi = self.settings["pct_high"] - step
        if hi - lo < 2.0:
            return
        self.settings["pct_low"] = round(min(lo, 49.0), 2)
        self.settings["pct_high"] = round(max(hi, 51.0), 2)
        self._on_contrast_changed()

    def contrast_decrease(self):
        """Widen the pct_low/pct_high window -> less contrast."""
        step = 2.0
        self.settings["pct_low"] = round(max(0.0, self.settings["pct_low"] - step), 2)
        self.settings["pct_high"] = round(min(100.0, self.settings["pct_high"] + step), 2)
        self._on_contrast_changed()

    def contrast_reset(self):
        self.settings["pct_low"] = cfg.DEFAULTS["pct_low"]
        self.settings["pct_high"] = cfg.DEFAULTS["pct_high"]
        self._on_contrast_changed()

    def _on_contrast_changed(self):
        cfg.save_settings(self.settings)
        self._update_contrast_label()
        self._apply_display_settings()

    def _update_contrast_label(self):
        lo = self.settings.get("pct_low", cfg.DEFAULTS["pct_low"])
        hi = self.settings.get("pct_high", cfg.DEFAULTS["pct_high"])
        self.contrast_level_label.setText(f"{lo:.0f}\u2013{hi:.0f}%")

    # ------------------------------------------------------------------
    # Classification
    # ------------------------------------------------------------------
    def on_key_action(self, action):
        if self.current_index is None:
            return
        if action == "back":
            self.go_back()
            return
        self.mark_verdict(action)

    def mark_verdict(self, label):
        df_index = self.current_index
        self.df.at[df_index, "verdict"] = label

        row = self._row_for_index(df_index)
        if row is not None:
            verdict_col = list(self.df.columns).index("verdict")
            item = self.table.item(row, verdict_col)
            if item is not None:
                item.setText(label)

        self._save_timer.start(300)  # debounce rapid key presses
        self.update_status()

        position = self._row_for_index(df_index)
        if position is not None and position + 1 < len(self.order):
            self.navigate_to(self.order[position + 1], record_history=True)
        else:
            self.statusBar().showMessage("Reached the end of the list.", 3000)

    def update_status(self):
        if self.df is None:
            self.status_label.setText("No CSV loaded")
            return
        counts = self.df["verdict"].value_counts()
        real = int(counts.get("real", 0))
        fake = int(counts.get("fake", 0))
        uncertain = int(counts.get("uncertain", 0))
        total = len(self.df)
        done = real + fake + uncertain
        self.status_label.setText(
            f"{os.path.basename(getattr(self, 'csv_path', ''))}  |  "
            f"{done}/{total} classified  (real={real}, fake={fake}, uncertain={uncertain})"
        )

    # ------------------------------------------------------------------
    # Saving
    # ------------------------------------------------------------------
    def _do_save(self):
        if self.df is None or self.classified_csv_path is None:
            return
        try:
            self.df.to_csv(self.classified_csv_path, index=False)
        except Exception as e:
            self.statusBar().showMessage(f"Save failed: {e}", 5000)

    # ------------------------------------------------------------------
    # Smoothing toggle (top-panel checkbox; mirrors Settings dialog)
    # ------------------------------------------------------------------
    def toggle_smoothing(self, checked):
        self.settings["smoothing_enabled"] = bool(checked)
        cfg.save_settings(self.settings)
        if self.cache is not None:
            self.cache.clear()
            if self.current_index is not None:
                self.navigate_to(self.current_index, record_history=False)

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------
    def edit_settings(self):
        dialog = SettingsDialog(self.settings, self)
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        new_settings = dialog.result_settings()

        # box_size/smoothing change the crop itself -> cache must be
        # invalidated and the current row re-cropped. pct_low/pct_high and
        # aperture_radius are display-only -> just redraw, instantly.
        extraction_changed = any(
            new_settings[k] != self.settings[k]
            for k in ("box_size", "smoothing_enabled", "smoothing_size")
        )
        display_changed = any(
            new_settings[k] != self.settings[k]
            for k in ("pct_low", "pct_high", "aperture_radius")
        )

        self.settings.update(new_settings)
        cfg.save_settings(self.settings)

        self.smooth_check.blockSignals(True)
        self.smooth_check.setChecked(bool(self.settings.get("smoothing_enabled", True)))
        self.smooth_check.blockSignals(False)
        self._update_contrast_label()

        if self.cache is not None and extraction_changed:
            self.cache.clear()
            if self.current_index is not None:
                self.navigate_to(self.current_index, record_history=False)
        elif display_changed:
            self.image_view.set_aperture_radius(self.settings["aperture_radius"])
            self._apply_display_settings()

    def closeEvent(self, event):
        self._do_save()
        super().closeEvent(event)

    # ------------------------------------------------------------------
    # Close table (top-left button; replaces the old File > Close-ish
    # workflow now that the menu bar is gone). Leaves any loaded FITS
    # image in place -- only the table/session is cleared.
    # ------------------------------------------------------------------
    def close_table(self):
        if self.df is None:
            self.statusBar().showMessage("No table is currently loaded.", 3000)
            return
        self._do_save()  # flush any pending verdicts before closing

        self.df = None
        self.order = []
        self.csv_path = None
        self.classified_csv_path = None
        self.cache = None
        self.current_index = None
        self.visit_history = []
        self.nav_position = -1

        self.table.clear()
        self.table.setRowCount(0)
        self.table.setColumnCount(0)
        self.image_view.clear()
        self.info_label.setText("")
        self.hover_label.setText("Hover over the image to inspect a pixel")
        self.csv_corner_btn.setChecked(False)

        self.update_status()
        self.statusBar().showMessage("Table closed.", 3000)

    # ------------------------------------------------------------------
    # Readme / help dialog (the top-right "i" button)
    # ------------------------------------------------------------------
    def show_readme(self):
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Verdict \u2014 Readme")
        dialog.resize(720, 620)
        layout = QtWidgets.QVBoxLayout(dialog)

        browser = QtWidgets.QTextBrowser()
        browser.setOpenExternalLinks(True)
        text = _readme_text()
        if hasattr(browser, "setMarkdown"):
            browser.setMarkdown(text)
        else:
            browser.setPlainText(text)
        layout.addWidget(browser)

        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        layout.addWidget(buttons)

        dialog.exec_()


def _excepthook(exc_type, exc_value, exc_tb):
    # Safety net: an unhandled exception on the main thread would otherwise
    # crash Qt silently. Show it instead of letting the app just close.
    import traceback
    msg = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    print(msg, file=sys.stderr)
    QtWidgets.QMessageBox.critical(None, "Unexpected error", msg[-2000:])


def main():
    sys.excepthook = _excepthook
    app = QtWidgets.QApplication(sys.argv)
    app.setStyleSheet(theme.STYLESHEET)
    app.setWindowIcon(_app_icon())
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
