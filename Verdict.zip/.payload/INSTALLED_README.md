# Verdict

Verdict is a desktop app for quickly classifying astronomical detections
as real, fake, or uncertain — by eye, from a cutout image centred on
each source's RA/Dec. Just point it at a FITS image and a CSV of
detections.

## Running Verdict

Double-click **Verdict** on your Desktop, or from a terminal:

```bash
./Verdict.sh
```

## Using Verdict

1. **File → Open FITS Image...** — pick the FITS image your detections
   were found in.
2. **File → Open CSV...** — pick any catalogue CSV with RA/Dec columns.
   Confirm the RA / Dec / magnitude columns in the dialog that appears —
   it guesses sensible defaults.
3. The catalogue appears as a table on the left. Use **Sort Mag ↑ / Sort
   Mag ↓** to sort by magnitude.
4. Click any row — its cutout appears on the right, scaled with a
   2nd/98th percentile stretch, with a red aperture circle at the source
   position.
5. Classify with the keyboard (or the on-screen buttons):

   | Key            | Action                                       |
   |----------------|-----------------------------------------------|
   | `←` or `A`     | mark **fake**, advance to the next row        |
   | `→` or `D`     | mark **real**, advance to the next row        |
   | `↓` or `S`     | mark **uncertain**, advance to the next row   |
   | `↑`            | go back to the previous row                   |

   Verdicts are written continuously to `<csv name>_classified.csv` next
   to the CSV you opened. Re-opening the same CSV later resumes any
   verdicts already saved.

### Settings

**Settings → Cutout settings...** lets you change box size, aperture
radius, scale percentiles, and cache look-ahead/behind — at any time.

## Notes

- Verdict only reads the CSV and the FITS image; it never modifies them.
- for any queries contact at knnazimrh@gmail.com
- Any CSV with recognizable RA/Dec (and, for sorting, magnitude) columns
  works — it doesn't need to come from any particular pipeline.
