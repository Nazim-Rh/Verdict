#!/usr/bin/env python3
"""Launch the Verdict classifier GUI.

Usage:
    python3 run_classifier.py
"""
from classifier.main import main

if __name__ == "__main__":
    main()
