"""Best-guess RA/Dec/magnitude column detection for arbitrary CSVs produced
by the pipeline (plain catalogues use RA/DEC/MAG; matched_combined.csv uses
suffixed names like RA_wav/DEC_wav/MAG_wav and RA_other/DEC_other/MAG_other).
The GUI always lets the user confirm/override the guess.
"""

_RA_CANDIDATES = ["RA", "RA_wav", "RA_other", "ALPHA_J2000", "RAdeg"]
_DEC_CANDIDATES = ["DEC", "DEC_wav", "DEC_other", "DELTA_J2000", "DEdeg"]
_MAG_CANDIDATES = ["MAG", "MAG_wav", "MAG_other"]
_X_CANDIDATES = ["X", "X_IMAGE", "XCENTROID", "XPOS", "X_PIX", "XWIN_IMAGE"]
_Y_CANDIDATES = ["Y", "Y_IMAGE", "YCENTROID", "YPOS", "Y_PIX", "YWIN_IMAGE"]


def _best_match(columns, candidates, contains_fallback):
    cols_lower = {c.lower(): c for c in columns}
    for cand in candidates:
        if cand.lower() in cols_lower:
            return cols_lower[cand.lower()]
    for c in columns:
        if contains_fallback in c.lower():
            return c
    return columns[0] if columns else None


def guess_columns(columns):
    """Return (ra_col, dec_col, mag_col) best guesses from a list of column
    names. mag_col may be None if nothing looks like a magnitude column."""
    columns = list(columns)
    ra_col = _best_match(columns, _RA_CANDIDATES, "ra")
    dec_col = _best_match(columns, _DEC_CANDIDATES, "dec")

    mag_col = None
    cols_lower = {c.lower(): c for c in columns}
    for cand in _MAG_CANDIDATES:
        if cand.lower() in cols_lower:
            mag_col = cols_lower[cand.lower()]
            break
    if mag_col is None:
        for c in columns:
            if "mag" in c.lower():
                mag_col = c
                break
    return ra_col, dec_col, mag_col


def guess_xy(columns):
    """Return (x_col, y_col) best guesses, or None where nothing matches.
    No loose substring fallback here (unlike RA/Dec) since a single letter
    like "x" matches too many unrelated column names."""
    columns = list(columns)
    cols_lower = {c.lower(): c for c in columns}
    x_col = next((cols_lower[c.lower()] for c in _X_CANDIDATES if c.lower() in cols_lower), None)
    y_col = next((cols_lower[c.lower()] for c in _Y_CANDIDATES if c.lower() in cols_lower), None)
    return x_col, y_col
