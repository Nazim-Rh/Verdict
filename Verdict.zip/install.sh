#!/usr/bin/env bash
# Verdict installer.
#
# Usage:
#   ./install.sh                 interactive — asks where to install
#   ./install.sh /some/path      install straight to /some/path (still asks to confirm)
#
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_DIR="$HOME/Verdict"
TARGET_DIR="${1:-}"

echo "=== Verdict installer ==="
echo ""

# Ask where to install.
if [ -z "$TARGET_DIR" ]; then
    read -r -p "Install location [$DEFAULT_DIR]: " TARGET_DIR
    TARGET_DIR="${TARGET_DIR:-$DEFAULT_DIR}"
fi

if [ -e "$TARGET_DIR" ]; then
    echo "Note: $TARGET_DIR already exists — its .verdict contents will be replaced."
fi

read -r -p "Install Verdict to '$TARGET_DIR'? [Y/n] " CONFIRM
CONFIRM="${CONFIRM:-Y}"
case "$CONFIRM" in
    [Yy]*) ;;
    *) echo "Installation cancelled."; exit 0 ;;
esac

echo ""
echo "Installing to: $TARGET_DIR"
mkdir -p "$TARGET_DIR"

# Hidden internals: the actual app code, kept out of sight.
rm -rf "$TARGET_DIR/.verdict"
mkdir -p "$TARGET_DIR/.verdict/assets"
cp -r "$SCRIPT_DIR/.payload/classifier" "$TARGET_DIR/.verdict/"
cp "$SCRIPT_DIR/.payload/run_classifier.py" "$TARGET_DIR/.verdict/"
cp "$SCRIPT_DIR/.payload/requirements.txt" "$TARGET_DIR/.verdict/"

# Icon: pick it up from the hidden payload's assets/verdict.png, if present.
ICON_SRC="$SCRIPT_DIR/.payload/assets/verdict.png"
ICON_DEST="$TARGET_DIR/.verdict/assets/verdict.png"
if [ -f "$ICON_SRC" ]; then
    cp "$ICON_SRC" "$ICON_DEST"
    echo "Using icon: verdict.png"
else
    ICON_DEST=""
    echo "No verdict.png found in .payload/assets — using a default icon instead."
fi

# Only these two are visible in the installed folder.
cp "$SCRIPT_DIR/.payload/Verdict.sh" "$TARGET_DIR/Verdict.sh"
cp "$SCRIPT_DIR/.payload/INSTALLED_README.md" "$TARGET_DIR/README.md"
chmod +x "$TARGET_DIR/Verdict.sh"

# Set up the Python environment and install requirements NOW, not on first run.
echo ""
echo "Setting up Verdict's environment..."
cd "$TARGET_DIR/.verdict"
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
deactivate
cd "$SCRIPT_DIR"

# Give the visible launcher and README a custom icon in file managers that support it (e.g. Nautilus).
if [ -n "$ICON_DEST" ] && command -v gio >/dev/null 2>&1; then
    gio set "$TARGET_DIR/Verdict.sh" "metadata::custom-icon" "file://$ICON_DEST" 2>/dev/null || true
    gio set "$TARGET_DIR/README.md" "metadata::custom-icon" "file://$ICON_DEST" 2>/dev/null || true
fi

# Find (or create) the Desktop folder.
DESKTOP_DIR="$HOME/Desktop"
if command -v xdg-user-dir >/dev/null 2>&1; then
    XDG_DESKTOP="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
    [ -n "$XDG_DESKTOP" ] && DESKTOP_DIR="$XDG_DESKTOP"
fi
mkdir -p "$DESKTOP_DIR"

DESKTOP_FILE="$DESKTOP_DIR/Verdict.desktop"
ICON_LINE="Icon=applications-science"
[ -n "$ICON_DEST" ] && ICON_LINE="Icon=$ICON_DEST"

cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Verdict
Comment=Astronomical detection classifier
Exec=bash -c "cd '$TARGET_DIR' && ./Verdict.sh"
Path=$TARGET_DIR
$ICON_LINE
Terminal=true
Categories=Science;Education;
EOF
chmod +x "$DESKTOP_FILE"

# Mark it trusted so GNOME/Nautilus etc. don't grey it out.
if command -v gio >/dev/null 2>&1; then
    gio set "$DESKTOP_FILE" "metadata::trusted" true 2>/dev/null || true
fi

echo ""
echo "Done."
echo "  Installed:  $TARGET_DIR  (only Verdict.sh and README.md are visible there)"
echo "  Desktop:    $DESKTOP_FILE"
echo ""
echo "Launch Verdict by double-clicking the Desktop icon, or run:"
echo "  $TARGET_DIR/Verdict.sh"
