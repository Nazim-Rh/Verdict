"""Cutout extraction for the Verdict classifier GUI.

For a given (RA, Dec), crops a box_size x box_size pixel region out of the
FITS image around that position, and optionally smooths it with a median
filter. `extract_cutout` returns the raw pixel array plus its own WCS, for
live interactive display (see classifier.image_view.FitsImageView), which
lets the GUI change colormap/scale/contrast instantly without recomputing
the crop. `make_cutout_png` (rendering a static PNG with matplotlib) is
kept for standalone/offline use but is no longer used by the live GUI.
"""
import numpy as np
from astropy.nddata import Cutout2D
from scipy.ndimage import median_filter


def extract_cutout(data, wcs, ra=None, dec=None, x=None, y=None, box_size=20,
                    smoothing_enabled=True, smoothing_size=3):
    """Crop a box_size x box_size region out of `data`, centred either on
    a sky position (ra, dec) resolved through `wcs`, or directly on a
    pixel position (x, y) -- useful when the image has no usable WCS.
    Pass either (ra, dec) or (x, y), not both.

    Returns (cutout_data, cutout_wcs): the raw (optionally median-filtered)
    pixel array, and the WCS describing that cropped array (so pixel ->
    sky conversions for the cutout don't need the original WCS/offset).
    `cutout_wcs` may not be meaningful if `wcs` itself has no valid
    projection (e.g. when falling back to X/Y positions).
    """
    if x is not None and y is not None:
        x_pix, y_pix = float(x), float(y)
    else:
        x_pix, y_pix = wcs.all_world2pix(ra, dec, 0)
        x_pix = float(x_pix)
        y_pix = float(y_pix)

    if not (np.isfinite(x_pix) and np.isfinite(y_pix)):
        raise ValueError(f"Invalid pixel position (RA={ra}, DEC={dec}, X={x}, Y={y})")

    cut = Cutout2D(data, position=(x_pix, y_pix), size=(box_size, box_size),
                    mode="partial", fill_value=np.nan, wcs=wcs)
    cutout_data = cut.data
    cutout_wcs = cut.wcs

    finite_mask = np.isfinite(cutout_data)
    finite = cutout_data[finite_mask]

    if smoothing_enabled and smoothing_size and int(smoothing_size) > 1 and finite.size > 0:
        # median_filter doesn't handle NaN well, so fill any NaN pixels
        # (from partial/edge cutouts) with the finite median before
        # filtering, then mask them back out afterwards.
        fill_value = float(np.median(finite))
        filled = np.where(finite_mask, cutout_data, fill_value)
        smoothed = median_filter(filled, size=int(smoothing_size), mode="nearest")
        cutout_data = np.where(finite_mask, smoothed, np.nan)

    return cutout_data, cutout_wcs


def make_cutout_png(data, wcs, ra, dec, out_path, box_size=20, aperture_radius=3.0,
                     pct_low=2.0, pct_high=98.0, cmap="gray",
                     smoothing_enabled=True, smoothing_size=3):
    """Create and save one classification cutout PNG.

    Parameters
    ----------
    data : 2D numpy array
        The full FITS image data.
    wcs : astropy.wcs.WCS
        WCS for `data`.
    ra, dec : float
        Source position in degrees.
    out_path : str
        Where to save the PNG.
    box_size : int
        Side length (pixels) of the square cutout.
    aperture_radius : float
        Radius (pixels) of the aperture circle drawn at the source position.
    pct_low, pct_high : float
        Percentiles used to set the display vmin/vmax (min-max scaling).
    cmap : str
        Matplotlib colormap name.
    smoothing_enabled : bool
        Whether to apply a median filter to the cutout before display.
    smoothing_size : int
        Kernel size (pixels) of the median filter, applied when
        `smoothing_enabled` is True. Values <= 1 are a no-op.
    """
    import matplotlib
    matplotlib.use("Agg")  # headless backend, safe to call from worker threads
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle

    x_pix, y_pix = wcs.all_world2pix(ra, dec, 0)
    x_pix = float(x_pix)
    y_pix = float(y_pix)

    if not (np.isfinite(x_pix) and np.isfinite(y_pix)):
        raise ValueError(f"WCS projection failed for RA={ra}, DEC={dec}")

    cut = Cutout2D(data, position=(x_pix, y_pix), size=(box_size, box_size),
                    mode="partial", fill_value=np.nan)
    cutout_data = cut.data

    finite_mask = np.isfinite(cutout_data)
    finite = cutout_data[finite_mask]

    if smoothing_enabled and smoothing_size and int(smoothing_size) > 1 and finite.size > 0:
        # median_filter doesn't handle NaN well, so fill any NaN pixels
        # (from partial/edge cutouts) with the finite median before
        # filtering, then mask them back out afterwards.
        fill_value = float(np.median(finite))
        filled = np.where(finite_mask, cutout_data, fill_value)
        smoothed = median_filter(filled, size=int(smoothing_size), mode="nearest")
        cutout_data = np.where(finite_mask, smoothed, np.nan)
        finite = cutout_data[finite_mask]

    if finite.size == 0:
        vmin, vmax = 0.0, 1.0
    else:
        vmin, vmax = np.nanpercentile(finite, [pct_low, pct_high])
        if vmin == vmax:
            vmax = vmin + 1.0

    fig = plt.figure(figsize=(3, 3), dpi=100)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.imshow(cutout_data, origin="lower", cmap=cmap, vmin=vmin, vmax=vmax,
              interpolation="nearest")

    # centre of the cutout in cutout-pixel coordinates (row, col) -> (y, x)
    cy = (cutout_data.shape[0] - 1) / 2.0
    cx = (cutout_data.shape[1] - 1) / 2.0
    circ = Circle((cx, cy), radius=aperture_radius, edgecolor="red",
                   facecolor="none", linewidth=1.5)
    ax.add_patch(circ)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlim(-0.5, cutout_data.shape[1] - 0.5)
    ax.set_ylim(-0.5, cutout_data.shape[0] - 0.5)

    fig.savefig(out_path, dpi=100)
    plt.close(fig)
    return out_path
